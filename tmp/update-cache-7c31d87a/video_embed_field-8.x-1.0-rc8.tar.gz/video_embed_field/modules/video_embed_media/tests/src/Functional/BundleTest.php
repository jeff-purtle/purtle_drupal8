<?php

namespace Drupal\Tests\video_embed_media\Functional;

use Drupal\Tests\video_embed_field\Functional\FunctionalTestBase;

/**
 * Test the video_embed_field media integration.
 *
 * @group video_embed_media
 */
class BundleTest extends FunctionalTestBase {

  /**
   * Modules to install.
   *
   * @var array
   */
  public static $modules = [
    'video_embed_field',
    'video_embed_media',
    'media_entity',
    'field_ui',
    'node',
    'image',
  ];

  /**
   * Test the dialog form.
   */
  public function testMediaBundleCreation() {
    $this->drupalLogin($this->adminUser);

    // Create a new media bundle.
    $this->drupalGet('admin/structure/media/add');
    $this->submitForm([
      'label' => 'Video Bundle',
      'id' => 'video_bundle',
      'type' => 'video_embed_field',
    ], t('Save media bundle'));
    $this->assertText('The media bundle Video Bundle has been added.');

    // Ensure the video field is added to the media entity.
    $this->drupalGet('admin/structure/media/manage/video_bundle/fields');
    $this->assertText('field_media_video_embed_field');
    $this->assertText('Video URL');

    // Add a media entity with the new field.
    $this->drupalGet('media/add/video_bundle');
    $this->submitForm([
      'name[0][value]' => 'Drupal video!',
      'field_media_video_embed_field[0][value]' => 'https://www.youtube.com/watch?v=XgYu7-DQjDQ',
    ], 'Save');
    // We should see the video thumbnail on the media page.
    $this->assertRaw('video_thumbnails/XgYu7-DQjDQ.jpg');

    // Add another field and change the configured media field.
    $this->drupalGet('admin/structure/media/manage/video_bundle/fields/add-field');
    $this->submitForm([
      'new_storage_type' => 'video_embed_field',
      'label' => 'New Video Field',
      'field_name' => 'new_video_field',
    ], 'Save and continue');
    $this->submitForm([], t('Save field settings'));
    $this->submitForm([], t('Save settings'));

    // Update video source field.
    $this->drupalGet('admin/structure/media/manage/video_bundle');
    $this->submitForm([
      'type_configuration[video_embed_field][source_field]' => 'field_new_video_field',
    ], t('Save media bundle'));

    // Create a video, populating both video URL fields.
    $this->drupalGet('media/add/video_bundle');
    $this->submitForm([
      'name[0][value]' => 'Another Video!',
      'field_media_video_embed_field[0][value]' => 'https://www.youtube.com/watch?v=XgYu7-DQjDQ',
      'field_new_video_field[0][value]' => 'https://www.youtube.com/watch?v=gnERPdAiuSo',
    ], t('Save'));

    // We should see the newly configured video thumbnail, but not the original.
    $this->assertRaw('video_thumbnails/gnERPdAiuSo.jpg');
    $this->assertNoRaw('video_thumbnails/XgYu7-DQjDQ.jpg');
  }

}

<?php

/**
 * @file
 * Contains \Drupal\backup_migrate\Form\SourceForm.
 */

namespace Drupal\backup_migrate\Form;

use Drupal\Core\Form\FormStateInterface;

/**
 * Class SourceForm.
 *
 * @package Drupal\backup_migrate\Form
 */
class SourceForm extends WrapperEntityForm {}

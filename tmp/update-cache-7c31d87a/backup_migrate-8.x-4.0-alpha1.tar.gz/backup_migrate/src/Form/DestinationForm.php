<?php

/**
 * @file
 * Contains \Drupal\backup_migrate\Form\DestinationForm.
 */

namespace Drupal\backup_migrate\Form;

/**
 * Class DestinationForm.
 *
 * @package Drupal\backup_migrate\Form
 */
class DestinationForm extends WrapperEntityForm {}
